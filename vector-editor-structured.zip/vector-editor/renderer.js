
let canvas = new fabric.Canvas('c', {
  width: 1000,
  height: 700,
  backgroundColor: 'white',
  selection: true
});

let tool = 'select';
let isDragging = false;
let selectionStart;
let history = [];

function setTool(t) {
  tool = t;
}

function addToHistory() {
  history.push(JSON.stringify(canvas));
  if (history.length > 20) history.shift();
}

function undo() {
  if (history.length > 0) {
    canvas.loadFromJSON(JSON.parse(history.pop()), () => canvas.renderAll());
  }
}

canvas.on('mouse:down', function(opt) {
  const pointer = canvas.getPointer(opt.e);
  if (tool === 'pen') {
    const path = new fabric.Path(`M ${pointer.x} ${pointer.y}`, {
      stroke: document.getElementById('stroke-color').value,
      fill: '',
      strokeWidth: 2
    });
    canvas.add(path);
  } else if (tool === 'rectangle') {
    const rect = new fabric.Rect({
      left: pointer.x,
      top: pointer.y,
      width: 100,
      height: 60,
      fill: document.getElementById('fill-color').value,
      stroke: document.getElementById('stroke-color').value,
      strokeWidth: 2
    });
    canvas.add(rect);
  } else if (tool === 'circle') {
    const circ = new fabric.Circle({
      left: pointer.x,
      top: pointer.y,
      radius: 40,
      fill: document.getElementById('fill-color').value,
      stroke: document.getElementById('stroke-color').value,
      strokeWidth: 2
    });
    canvas.add(circ);
  } else if (tool === 'brush') {
    canvas.isDrawingMode = true;
    canvas.freeDrawingBrush.color = document.getElementById('stroke-color').value;
    canvas.freeDrawingBrush.width = 3;
  } else if (tool === 'text') {
    const text = new fabric.IText('Text', {
      left: pointer.x,
      top: pointer.y,
      fill: document.getElementById('fill-color').value
    });
    canvas.add(text);
  } else {
    canvas.isDrawingMode = false;
  }
  addToHistory();
});

document.addEventListener("keydown", (e) => {
  if (e.ctrlKey && e.key === "z") undo();
  if (e.ctrlKey && e.key === "g") canvas.getActiveObjects().length > 1 && canvas.discardActiveObject() && canvas.add(new fabric.Group(canvas.getActiveObjects()));
  if (e.key === "Delete") canvas.getActiveObjects().forEach(o => canvas.remove(o));
});

function saveProject() {
  const data = JSON.stringify(canvas.toJSON());
  const blob = new Blob([data], { type: "application/json" });
  const a = document.createElement("a");
  a.href = URL.createObjectURL(blob);
  a.download = "project.json";
  a.click();
}

document.getElementById('loadProject').addEventListener('change', function(e) {
  const reader = new FileReader();
  reader.onload = () => canvas.loadFromJSON(JSON.parse(reader.result), () => canvas.renderAll());
  reader.readAsText(e.target.files[0]);
});

function exportSVG() {
  const svg = canvas.toSVG();
  const blob = new Blob([svg], { type: "image/svg+xml" });
  const a = document.createElement("a");
  a.href = URL.createObjectURL(blob);
  a.download = "canvas.svg";
  a.click();
}

function importImage() {
  const input = document.createElement('input');
  input.type = 'file';
  input.accept = 'image/*';
  input.onchange = (e) => {
    const reader = new FileReader();
    reader.onload = () => {
      fabric.Image.fromURL(reader.result, function(img) {
        img.set({ left: 100, top: 100, scaleX: 0.5, scaleY: 0.5 });
        canvas.add(img);
      });
    };
    reader.readAsDataURL(input.files[0]);
  };
  input.click();
}

function toggleRulers() {
  alert('Rulers toggle coming soon!');
}
